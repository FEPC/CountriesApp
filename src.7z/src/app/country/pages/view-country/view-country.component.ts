import { Component } from '@angular/core';

@Component({
  selector: 'app-view-country',
  templateUrl: './view-country.component.html',
})
export class ViewCountryComponent {
 
}
