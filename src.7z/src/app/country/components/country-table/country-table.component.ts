import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-country-table',
  templateUrl: './country-table.component.html',
  styles: [
  ]
})
export class CountryTableComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
